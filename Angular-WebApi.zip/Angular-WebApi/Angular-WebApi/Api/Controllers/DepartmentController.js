﻿/// <reference path="../../Scripts/angular.js" />
(function () {
    'use strict';

    angular.module('app').controller('DepartmentController', ['$scope', function ($scope) {
    }]);
})();