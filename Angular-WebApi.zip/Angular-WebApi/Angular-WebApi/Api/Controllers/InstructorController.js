﻿/// <reference path="../../Scripts/angular.js" />
(function () {
    'use strict';

    angular.module('app').controller('InstructorController', ['$scope', function ($scope) {
    }]);
})();