﻿/// <reference path="../../Scripts/angular.js" />


    angular.module('app').controller('StudentController', ['$scope', 'StudentService', function ($scope, StudentService) {
        $scope.toggle = false;
        $scope.sortBy = 'Name';
        $scope.reverse = false;

        StudentService.getStudents()
            .then(function (data) {
                $scope.students = data.data;
            },
            function (error) {
            });

        $scope.toggleEdit = function () {
            this.toggle = !this.toggle;
        };

        $scope.Save = function (student) {
            console.log(student);
            $scope.students= StudentService.updateStudent(student);
            this.toggle = !this.toggle;
        };

        $scope.orderBy = function (sortKey) {
            $scope.sortBy = sortKey;
            $scope.reverse = !$scope.reverse;
        }

        $scope.DeleteStudent = function (student) {

            var action = confirm('Do you want to delete?');
            if (action) {
                $scope.students = StudentService.deleteStudent(student);
            }

        };

        $scope.createStudent = function (student) {
            StudentService.createStudent(student)
                .then(function (data) {
                    $scope.students.push(data.data);
                },
                function (error) {
                });
            $('#addstudent').modal('hide');
        };
    }]);
