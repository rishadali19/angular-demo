﻿/// <reference path="../../Scripts/angular.js" />
(function () {
    'use strict';

    angular.module('app').controller('CourseController', ['$scope', 'CourseService', function ($scope, CourseService) {
        
        $scope.sortBy = 'CourseID';
        $scope.reverse = false;
        $scope.toggle = false;

        $scope.courses = CourseService.getCourses();

        $scope.createCourse = function (course) {
            console.log(course);
            $scope.courses = CourseService.createCourse(course);
            $('#addcourse').modal('hide');
        };

        $scope.save = function (course) {
            $scope.courses = CourseService.updateCourse(course);
            this.toggle = !this.toggle;
            console.log($scope.courses);
        };
        
        $scope.orderBy = function (sortKey) {
            $scope.sortBy = sortKey;
            $scope.reverse = !$scope.reverse;
        };

        $scope.DeleteCourse = function (course) {

            var action = confirm('Do you want to delete ?');
            if (action) {
                $scope.courses = CourseService.deleteCourse(course);
            }
            
        };

        $scope.toggleEdit = function () {
            this.toggle = !this.toggle;
        };
    }]);
})();