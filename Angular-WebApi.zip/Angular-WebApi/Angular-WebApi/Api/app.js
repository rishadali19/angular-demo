﻿/// <reference path="../Scripts/angular.min.js" />
var app = angular.module('app', ['ngRoute'])
        .config(config)
        .run(run);



config.$inject = ['$routeProvider', '$locationProvider'];
function config($routeProvider, $locationProvider) {

    $routeProvider
        .when('/', {
            templateUrl: '/Api/Views/Dashbord.html'
        })
        .when('/Students', {
            templateUrl: '/Api/Views/Students.html',
            controller: 'StudentController'
        })
        .when('/Departments', {
            templateUrl: '/Api/Views/Departments.html',
            controller: 'DepartmentController'
        }).when('/Courses', {
            templateUrl: '/Api/Views/Courses.html',
            controller: 'CourseController'
        });

    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
}

function run($rootScope) {
    $rootScope.baseUrl = "http://localhost:53837/";
}