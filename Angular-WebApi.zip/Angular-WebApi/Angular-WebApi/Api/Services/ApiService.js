﻿/// <reference path="../../Scripts/angular.js" />
(function () {
    'use strict';

    angular.module('app').factory('ApiService', ['$http', '$rootScope', function ($http, $rootScope) {
        
        var service = {
            get: get,
            post: post,
            update: update,
            del: del
        };
       

    }]);

})();