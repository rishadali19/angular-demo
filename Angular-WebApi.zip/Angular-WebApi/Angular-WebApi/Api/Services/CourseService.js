﻿/// <reference path="../../Scripts/angular.js" />
(function () {
    'use strict';

    angular.module('app').factory('CourseService', ['$http', '$rootScope', function ($http, $rootScope) {

        var service = {
            getCourses   : _geCourses,
            createCourse : _createCourse,
            updateCourse : _updateCourse,
            deleteCourse : _deleteCourse
        };

        var courses = [];
        function _geCourses() {
            courses = [];
            courses.push({ CourseID: 1050, Title: "Chemistry", Credits: 3, });
            courses.push({ CourseID: 4022, Title: "Microeconomics", Credits: 3 });
            courses.push({ CourseID: 4041, Title: "Macroeconomics", Credits: 3 });
            courses.push({ CourseID: 1045, Title: "Calculus", Credits: 4 });
            courses.push({ CourseID: 3141, Title: "Trigonometry", Credits: 4 });
            courses.push({ CourseID: 2021, Title: "Composition", Credits: 3 });
            courses.push({ CourseID: 2042, Title: "Literature", Credits: 4 });

            return courses;
        };

        function _createCourse(course) {
            courses.push(course);
            return courses;
        };

        function _updateCourse(course) {
            $.each(courses, function (i) {
                if (courses[i].CourseID === course.CourseID) {
                    courses[i].Title = course.Title;
                    courses[i].CourseID = course.CourseID;
                    courses[i].Credits = course.Credits;
                }
                return;
            });
            return courses;
        };

        function _deleteCourse(course) {
            $.each(courses, function (i) {
                if (courses[i].CourseID === course.CourseID) {
                    courses.splice(i, 1);
                    return;
                }
            });
            return courses;
        };


        return service;

    }]);
    
})();