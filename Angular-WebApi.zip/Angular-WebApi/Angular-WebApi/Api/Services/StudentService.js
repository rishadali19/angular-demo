﻿/// <reference path="../../Scripts/angular.js" />

    angular.module('app').factory('StudentService', ['$http', '$rootScope', function ($http, $rootScope) {


        var baseurl= $rootScope.baseUrl;
        var services = {
            createStudent: _createStudent,
            getStudents: _getStudents,
            updateStudent: _updateStudent,
            deleteStudent: _deleteStudent
        };
        var students = [];

        function _getStudents() {
           return $http.get(baseurl + 'api/StudentApi/GetStudents');
        };

        function _createStudent(student) {
          return  $http.post(baseurl + 'api/StudentApi/AddStudent', student);
        };

        function _updateStudent(student) {
            $.each(students, function () {
                if (this.Name == student.Name) {
                    this.Email = student.Email;
                    this.Mobile = student.Mobile;
                    this.Enrollment = student.Enrollment;
                }
            });
            return students;
        };

        function _deleteStudent(student) {
            $.each(students, function (i) {
                if (students[i].Name == student.Name) {
                    students.splice(i, 1);
                }
            });
            return students;
            
        };
        return services;
    }]);
