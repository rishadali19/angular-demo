﻿/// <reference path="../../Scripts/angular.js" />
(function () {
    'use strict';
})();